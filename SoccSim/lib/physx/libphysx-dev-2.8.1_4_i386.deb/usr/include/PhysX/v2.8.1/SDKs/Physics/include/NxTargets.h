#ifndef NX_PHYSICS_NXTARGETS
#define NX_PHYSICS_NXTARGETS

#include "NxSwTarget.h"
#if NX_ENABLE_HW_PARSER
#include "NxHwTarget.h"
#endif

#endif
//AGCOPYRIGHTBEGIN
///////////////////////////////////////////////////////////////////////////
// Copyright (c) 2007 AGEIA Technologies.
// All rights reserved. www.ageia.com
///////////////////////////////////////////////////////////////////////////
//AGCOPYRIGHTEND
